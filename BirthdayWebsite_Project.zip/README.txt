Upload these files to your GitHub repository:
- index.html
- style.css
- script.js
- mem.jpg
- memo.jpg
- Mashooqa.mp3 (optional)

Paste your complete birthday message into the <div class="letter"> section in index.html.
