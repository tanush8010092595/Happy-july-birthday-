function openLetter(){
 const env=document.querySelector('.envelope');
 env.classList.add('open');
 setTimeout(()=>{
   document.getElementById('loading').style.display='none';
   document.getElementById('main').classList.remove('hidden');
   const bgm=document.getElementById('bgm');
   if(bgm){bgm.play().catch(()=>{});}
 },1100);
}
